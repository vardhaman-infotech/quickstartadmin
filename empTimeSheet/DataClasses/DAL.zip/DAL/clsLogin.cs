﻿using System.Data;
using empTimeSheet.DataClasses.DAL;
using System.Web;

namespace empTimeSheet
{
    public class clsLogin:clsDAL
    {
      
        private string _loginid, _password, _usertype, _dob,_action,_company;
  

        public clsLogin()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Variables

        public string company
        {
            get
            {
                return this._company;
            }
            set
            {
                this._company = value.Trim();
            }
        }

        public string action
        {
            get
            {
                return this._action;
            }
            set
            {
                this._action = value.Trim();
            }
        }
        public string loginid
        {
            get
            {
                return this._loginid;
            }
            set
            {
                this._loginid = value.Trim();
            }
        }

        public string password
        {
            get
            {
                return this._password;
            }
            set
            {
                this._password = value.Trim();
            }
        }
        public string usertype
        {
            get
            {
                return this._usertype;
            }
            set
            {
                this._usertype = value.Trim();
            }
        }
        public string dob
        {
            get
            {
                return this._dob;
            }
            set
            {
                this._dob = value.Trim();
            }
        }
        #endregion


        public DataSet login()
        {
            dbcommand = db.GetStoredProcCommand("sp_login", loginid, password, company, action);
           return  db.ExecuteDataSet(dbcommand);
            
        }
    }
}