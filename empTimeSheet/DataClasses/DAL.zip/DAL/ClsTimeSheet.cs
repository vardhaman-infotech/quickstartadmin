﻿using System.Data;
using empTimeSheet.DataClasses.DAL;
using System.Web;

public class ClsTimeSheet:clsDAL
{
   
    private string _action, _nid, _Code, _name, _companyId, _clientid, _managerId, _contractType, _Status, _contractAmt, _expAmt;
    private string _serviceAmt, _startdate, _duedate, _completePercent, _currencyID, _iscustominvoice, _invoicePrefix, _invoiceSuffix, _invoicesno;
    private string _remark, _CreatedBy, _keyword, _from, _to, _frequency, _po, _description, _isbillable, _deptID, _costrate, _billrate;
    private string _empid, _taskid, _projectid, _hours, _isbilled, _tax, _type;
    private string _grade, _groupid;


    private string _expenseid, _units, _cost, _MU, _date, _amount;
    #region Variables
    public string action { get { return this._action; } set { this._action = value.Trim(); } }
    public string nid { get { return this._nid; } set { this._nid = value.Trim(); } }
    public string Code { get { return this._Code; } set { this._Code = value.Trim(); } }
    public string name { get { return this._name; } set { this._name = value.Trim(); } }
    public string companyId { get { return this._companyId; } set { this._companyId = value.Trim(); } }
    public string clientid { get { return this._clientid; } set { this._clientid = value.Trim(); } }
    public string managerId { get { return this._managerId; } set { this._managerId = value.Trim(); } }
    public string contractType { get { return this._contractType; } set { this._contractType = value.Trim(); } }
    public string Status { get { return this._Status; } set { this._Status = value.Trim(); } }
    public string contractAmt { get { return this._contractAmt; } set { this._contractAmt = value.Trim(); } }
    public string expAmt { get { return this._expAmt; } set { this._expAmt = value.Trim(); } }
    public string serviceAmt { get { return this._serviceAmt; } set { this._serviceAmt = value.Trim(); } }
    public string startdate { get { return this._startdate; } set { this._startdate = value.Trim(); } }
    public string duedate { get { return this._duedate; } set { this._duedate = value.Trim(); } }
    public string completePercent { get { return this._completePercent; } set { this._completePercent = value.Trim(); } }
    public string currencyID { get { return this._currencyID; } set { this._currencyID = value.Trim(); } }
    public string iscustominvoice { get { return this._iscustominvoice; } set { this._iscustominvoice = value.Trim(); } }
    public string invoicePrefix { get { return this._invoicePrefix; } set { this._invoicePrefix = value.Trim(); } }
    public string invoiceSuffix { get { return this._invoiceSuffix; } set { this._invoiceSuffix = value.Trim(); } }
    public string invoicesno { get { return this._invoicesno; } set { this._invoicesno = value.Trim(); } }
    public string remark { get { return this._remark; } set { this._remark = value.Trim(); } }
    public string frequency { get { return this._frequency; } set { this._frequency = value.Trim(); } }
    public string po { get { return this._po; } set { this._po = value.Trim(); } }


    public string CreatedBy { get { return this._CreatedBy; } set { this._CreatedBy = value.Trim(); } }
    public string keyword { get { return this._keyword; } set { this._keyword = value.Trim(); } }
    public string from { get { return this._from; } set { this._from = value.Trim(); } }
    public string to { get { return this._to; } set { this._to = value.Trim(); } }

    public string description { get { return this._description; } set { this._description = value.Trim(); } }
    public string isbillable { get { return this._isbillable; } set { this._isbillable = value.Trim(); } }
    public string deptID { get { return this._deptID; } set { this._deptID = value.Trim(); } }
    public string costrate { get { return this._costrate; } set { this._costrate = value.Trim(); } }
    public string billrate { get { return this._billrate; } set { this._billrate = value.Trim(); } }
    public string empid { get { return this._empid; } set { this._empid = value.Trim(); } }
    public string taskid { get { return this._taskid; } set { this._taskid = value.Trim(); } }
    public string projectid { get { return this._projectid; } set { this._projectid = value.Trim(); } }
    public string hours { get { return this._hours; } set { this._hours = value.Trim(); } }
    public string isbilled { get { return this._isbilled; } set { this._isbilled = value.Trim(); } }

    public string expenseid { get { return this._expenseid; } set { this._expenseid = value.Trim(); } }
    public string units { get { return this._units; } set { this._units = value.Trim(); } }
    public string cost { get { return this._cost; } set { this._cost = value.Trim(); } }
    public string MU { get { return this._MU; } set { this._MU = value.Trim(); } }
    public string date { get { return this._date; } set { this._date = value.Trim(); } }
    public string amount { get { return this._amount; } set { this._amount = value.Trim(); } }
    public string tax { get { return this._tax; } set { this._tax = value.Trim(); } }
    public string type { get { return this._type; } set { this._type = value.Trim(); } }

    public string grade { get { return this._grade; } set { this._grade = value.Trim(); } }
    public string groupid { get { return this._groupid; } set { this._groupid = value.Trim(); } }

    #endregion

    #region Method

    public DataSet ManageProject()
    {
        dbcommand = db.GetStoredProcCommand("sp_project", action, nid, Code, name, companyId, clientid, managerId, contractType,
                     Status, contractAmt, expAmt, serviceAmt, startdate, duedate, completePercent, currencyID, iscustominvoice, invoicePrefix,
                     invoiceSuffix, invoicesno, remark, frequency, po, CreatedBy, keyword, from, to);
        return db.ExecuteDataSet(dbcommand);
    }

    public DataSet ManageTasks()
    {
        dbcommand = db.GetStoredProcCommand("sp_task", action, nid, Code, name, description, isbillable, Status, companyId, deptID, CreatedBy, costrate, billrate, tax, type, hours);
        return db.ExecuteDataSet(dbcommand);
    }


    //------------------------------------Manage Expenses-------------------------------------------------------------

    public DataSet ManageExpenses()
    {
        dbcommand = db.GetStoredProcCommand("sp_expense", action, nid, Code, name, description, costrate, billrate, isbillable, companyId, Status, CreatedBy);
        return db.ExecuteDataSet(dbcommand);
    }


    public DataSet ReviewTimeExpense()
    {
        dbcommand = db.GetStoredProcCommand("sp_Reviewtimeexp", action, nid, date, empid, projectid, taskid, description, hours, units, Status, from, to);
        return db.ExecuteDataSet(dbcommand);
    }


    #endregion


    #region Assign Tasks
    public DataSet AssignTasks()
    {
        dbcommand = db.GetStoredProcCommand("sp_Assignment", action, nid, date, empid, clientid, taskid, Status, hours, remark, grade, description, companyId, CreatedBy, from, to,groupid,projectid);
        return db.ExecuteDataSet(dbcommand);
    }

    #endregion


    #region Schedule

    public DataSet schedule()
    {
        dbcommand = db.GetStoredProcCommand("sp_Schedule",action,nid,empid,clientid,date,hours,Status,remark,CreatedBy,companyId,from,to,projectid);
        return db.ExecuteDataSet(dbcommand);


    }
    public DataSet insertschedule()
    {
        dbcommand = db.GetStoredProcCommand("sp_insertschedule", empid, clientid, date, Status, remark, CreatedBy, companyId, from, to,projectid);
        return db.ExecuteDataSet(dbcommand);


    }
    public DataSet checkschedule()
    {
        dbcommand = db.GetStoredProcCommand("sp_checkschedulexists",empid,clientid,companyId,from,to);
        return db.ExecuteDataSet(dbcommand);


    }
    public DataSet GetPerformanceRpt()
    {
        dbcommand = db.GetStoredProcCommand("sp_performanceReport", empid, clientid, taskid, companyId, from, to);
        return db.ExecuteDataSet(dbcommand);


    }

    public DataSet GetCalendar()
    {
        //Here "managerid" used to Pass employee ID to get Assigned TAsks and "empid" to pass employee id for Schedule
        dbcommand = db.GetStoredProcCommand("sp_calendar", action,empid,managerId, from, to, companyId);
        return db.ExecuteDataSet(dbcommand);


    }
    #endregion

}

