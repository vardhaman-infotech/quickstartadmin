﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlTypes;
using System.Data.Sql;
using System.Data.SqlClient;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data.Common;
using System.Data;
using System.Net;
using System.Xml;
using System.Web.Mail;
using System.Collections;
using System.Net.Mail;



public class DataAccess
{
    DataSet ds = new DataSet();
    static string connString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
    DbCommand dbcommand;
    SqlDatabase db = new SqlDatabase(connString);
    public static SqlConnection scon = new SqlConnection(connString);
    private string _loginid, _password, _usertype, _dob, _dob2, _date, _name, _id, _empid, _taskid, _projectid, _clientid, _description, _action, _company, _parentid;


    public DataAccess()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    #region Variables
    public string parentid
    {
        get
        {
            return this._parentid;
        }
        set
        {
            this._parentid = value.Trim();
        }
    }
    public string name
    {
        get
        {
            return this._name;
        }
        set
        {
            this._name = value.Trim();
        }
    }
    public string date
    {
        get
        {
            return this._date;
        }
        set
        {
            this._date = value.Trim();
        }
    }
    public string dob2
    {
        get
        {
            return this._dob2;
        }
        set
        {
            this._dob2 = value.Trim();
        }
    }
    public string clientid
    {
        get
        {
            return this._clientid;
        }
        set
        {
            this._clientid = value.Trim();
        }
    }
    public string description
    {
        get
        {
            return this._description;
        }
        set
        {
            this._description = value.Trim();
        }
    }
    public string id
    {
        get
        {
            return this._id;
        }
        set
        {
            this._id = value.Trim();
        }
    }
    public string company
    {
        get
        {
            return this._company;
        }
        set
        {
            this._company = value.Trim();
        }
    }
    public string projectid
    {
        get
        {
            return this._projectid;
        }
        set
        {
            this._projectid = value.Trim();
        }
    }
    public string taskid
    {
        get
        {
            return this._taskid;
        }
        set
        {
            this._taskid = value.Trim();
        }
    }

    public string empid
    {
        get
        {
            return this._empid;
        }
        set
        {
            this._empid = value.Trim();
        }
    }

    public string action
    {
        get
        {
            return this._action;
        }
        set
        {
            this._action = value.Trim();
        }
    }
    public string loginid
    {
        get
        {
            return this._loginid;
        }
        set
        {
            this._loginid = value.Trim();
        }
    }

    public string password
    {
        get
        {
            return this._password;
        }
        set
        {
            this._password = value.Trim();
        }
    }
    public string usertype
    {
        get
        {
            return this._usertype;
        }
        set
        {
            this._usertype = value.Trim();
        }
    }
    public string dob
    {
        get
        {
            return this._dob;
        }
        set
        {
            this._dob = value.Trim();
        }
    }
    #endregion

    #region common Function
    /// <summary>
    /// send to multi receiver
    /// Send email with CC and BCC and file
    /// </summary>
    /// <param name="receiver"></param>
    /// <param name="subject"></param>
    /// <param name="message"></param>
    /// <param name="cc"></param>
    /// <param name="bcc"></param>
    /// <param name="filename"></param>
    /// <returns></returns>
    public string SendEmail(string receiver, string subject, string message, string cc, string bcc, string filename)
    {

        string sender = System.Web.Configuration.WebConfigurationManager.AppSettings["SenderEmail"].ToString();
        string pass = System.Web.Configuration.WebConfigurationManager.AppSettings["SenderPass"].ToString();
        string hostname = System.Web.Configuration.WebConfigurationManager.AppSettings["MailHost"].ToString();

        System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
        string msg = "";
        if (receiver != "")
        {
            string[] strto = receiver.Split(',');

            for (int i = 0; i < strto.Length - 1; i++)
            {
                mail.To.Add(new MailAddress(strto[i]));

            }
        }

        mail.From = new MailAddress(sender);
        mail.Subject = subject;
        mail.Body = message;
        if (cc != "")
        {
            string[] strcc = cc.Split(',');

            for (int i = 0; i < strcc.Length - 1; i++)
            {
                mail.CC.Add(new MailAddress(strcc[i]));

            }
        }
        if (bcc != "")
        {
            string[] strbcc = bcc.Split(',');

            for (int i = 0; i < strbcc.Length - 1; i++)
            {
                mail.Bcc.Add(new MailAddress(strbcc[i]));

            }
        }
        if (filename != "")
        {

            mail.Attachments.Add(new System.Net.Mail.Attachment(HttpContext.Current.Server.MapPath("files/Temp/" + filename)));
        }
        mail.IsBodyHtml = true;
        SmtpClient smtp = new SmtpClient();
        smtp.Host = hostname;

        smtp.Credentials = new System.Net.NetworkCredential(sender, pass);
        //  smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
        // smtp.Port = 25;
        //smtp.EnableSsl = true;
        try
        {
            smtp.Send(mail); msg = "Sent";
        }
        catch (Exception ex)
        {

            msg = ex.ToString();
        }

        return msg;
    }
    #endregion

    #region Previleges

    public DataSet getallrole()
    {
        dbcommand = db.GetStoredProcCommand("sp_rolemaster", "getallrole", "", "", "", "");
        ds = db.ExecuteDataSet(dbcommand);
        return ds;

    }

    public bool checkUserInroles(string roleid)
    {
        dbcommand = db.GetStoredProcCommand("sp_rolemaster", "getUserInRoles", "", HttpContext.Current.Session["userid"].ToString(), "", roleid);
        ds = db.ExecuteDataSet(dbcommand);
        if (ds.Tables[0].Rows.Count > 0)
            return true;
        else
            return false;

    }
    public DataTable checkUserInroles(string roleid, DataSet ds)
    {
        DataView dv = new DataView(ds.Tables[0]);
        dv.RowFilter = "nid='" + roleid + "'";
        return dv.ToTable();
    }
    public DataSet getUserInRoles()
    {
        dbcommand = db.GetStoredProcCommand("sp_rolemaster", "getUserInRoles", loginid, id, "", "");
        ds = db.ExecuteDataSet(dbcommand);
        return ds;

    }
    public bool validatedRoles(string roleid, DataSet ds)
    {
        DataTable dt = new DataTable();
        dt = checkUserInroles(roleid, ds);
        if (dt.Rows.Count > 0)
            return true;
        else
            return false;
    }

    #endregion

    public DataSet designation()
    {
        dbcommand = db.GetStoredProcCommand("sp_Designation", action, id, name, description, company);
        return db.ExecuteDataSet(dbcommand);

    }
    public DataSet department()
    {
        dbcommand = db.GetStoredProcCommand("sp_Department", action, id, name, description, company);
        return db.ExecuteDataSet(dbcommand);

    }
    public DataSet roles()
    {
        dbcommand = db.GetStoredProcCommand("sp_roles", action);
        return db.ExecuteDataSet(dbcommand);

    }
    public DataSet currency()
    {
        dbcommand = db.GetStoredProcCommand("sp_currency", action);
        return db.ExecuteDataSet(dbcommand);

    }
    public DataSet ManageMaster()
    {
        dbcommand = db.GetStoredProcCommand("sp_managemaster", action, id, name, parentid, "");
        return db.ExecuteDataSet(dbcommand);


    }
    public DataSet AnnouncementMaster()
    {
        dbcommand = db.GetStoredProcCommand("sp_AnnouncementMaster", action, id, name, description, dob, dob2, loginid, usertype, company);
        ds = db.ExecuteDataSet(dbcommand);
        return ds;
    }
}
