﻿using System.Data;
using empTimeSheet.DataClasses.DAL;

public class ClsPayroll : clsDAL
{

    private string _action, _nid, _Empid, _Date, _NumofDays, _RequestDate, _Leavetypeid, _Description, _Createdby, _Status, _Remark, _ApprovDate, _Companyid, _from, _to, _type;
    private string _year, _month, _name;
    private string _title, _calType, _calGroup,_amount;

    #region Variables

    public string amount { get { return this._amount; } set { this._amount = value.Trim(); } }
    public string title { get { return this._title; } set { this._title = value.Trim(); } }
    public string calType { get { return this._calType; } set { this._calType = value.Trim(); } }
    public string calGroup { get { return this._calGroup; } set { this._calGroup = value.Trim(); } }

    public string action { get { return this._action; } set { this._action = value.Trim(); } }
    public string nid { get { return this._nid; } set { this._nid = value.Trim(); } }
    public string Empid { get { return this._Empid; } set { this._Empid = value.Trim(); } }
    public string Date { get { return this._Date; } set { this._Date = value.Trim(); } }
    public string NumofDays { get { return this._NumofDays; } set { this._NumofDays = value.Trim(); } }
    public string RequestDate { get { return this._RequestDate; } set { this._RequestDate = value.Trim(); } }
    public string Leavetypeid { get { return this._Leavetypeid; } set { this._Leavetypeid = value.Trim(); } }
    public string Description { get { return this._Description; } set { this._Description = value.Trim(); } }
    public string Createdby { get { return this._Createdby; } set { this._Createdby = value.Trim(); } }
    public string Status { get { return this._Status; } set { this._Status = value.Trim(); } }
    public string Remark { get { return this._Remark; } set { this._Remark = value.Trim(); } }
    public string ApprovDate { get { return this._ApprovDate; } set { this._ApprovDate = value.Trim(); } }
    public string companyid { get { return this._Companyid; } set { this._Companyid = value.Trim(); } }
    public string from { get { return this._from; } set { this._from = value.Trim(); } }
    public string to { get { return this._to; } set { this._to = value.Trim(); } }
    public string type { get { return this._type; } set { this._type = value.Trim(); } }


    public string year { get { return this._year; } set { this._year = value.Trim(); } }
    public string month { get { return this._month; } set { this._month = value.Trim(); } }
    public string name { get { return this._name; } set { this._name = value.Trim(); } }
    #endregion


    #region Payroll
    public DataSet LeaveRequest()
    {
        dbcommand = db.GetStoredProcCommand("sp_LeaveRequest", action, nid, Empid, Date, NumofDays, RequestDate, Leavetypeid, Description, Createdby, Status, Remark, ApprovDate, companyid, from, to);
        return db.ExecuteDataSet(dbcommand);
    }
    public DataSet Holiday()
    {
        dbcommand = db.GetStoredProcCommand("sp_holiday", action, nid, Date, name, companyid, Createdby, from, to, year, month);
        return db.ExecuteDataSet(dbcommand);
    }

    public DataSet salaryStructure()
    {
        dbcommand = db.GetStoredProcCommand("salaryStructure", action, nid, title, amount, calType, calGroup, companyid);
        return db.ExecuteDataSet(dbcommand);
    }
    #endregion
}
