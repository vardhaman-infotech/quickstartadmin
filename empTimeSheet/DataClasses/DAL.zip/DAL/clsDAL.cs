﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlTypes;
using System.Data.Sql;
using System.Data.SqlClient;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data.Common;
using System.Data;

namespace empTimeSheet.DataClasses.DAL
{
    public class clsDAL
    {
        static string connString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        public DbCommand dbcommand;
        public SqlDatabase db = new SqlDatabase(connString);
        public static SqlConnection scon = new SqlConnection(connString);
    }
}